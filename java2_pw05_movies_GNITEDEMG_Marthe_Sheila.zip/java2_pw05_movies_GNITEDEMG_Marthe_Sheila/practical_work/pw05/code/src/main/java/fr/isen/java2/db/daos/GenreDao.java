package fr.isen.java2.db.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.lang.RuntimeException;
import javax.sql.DataSource;

import fr.isen.java2.db.entities.Genre;

public class GenreDao {
	DataSource dataSource = DataSourceFactory.getDataSource();

	public List<Genre> listGenres(){
		List<Genre> listOfGenres = new ArrayList<>();
		
		try (Connection connection = dataSource.getConnection()) {
	        try (Statement statement = connection.createStatement()) {
	            try (ResultSet results = statement.executeQuery("SELECT * from genre")) {
	                while (results.next()) {
	                    Genre genre = new Genre(results.getInt("id"),
	                                            results.getString("name"));
	                    
	                    listOfGenres.add(genre);
	                }
	            }
	        }
	    } catch (SQLException e) {
	        
	    	e.printStackTrace();
	    }
	    return listOfGenres;
	}

	public Genre getGenre(String name) {
		 try (Connection connection = dataSource.getConnection()) {
		        try (PreparedStatement statement = connection.prepareStatement(
		                    "SELECT * from genre where name='Comedy'")) {
		            statement.setString(1, name);
		            try (ResultSet results = statement.executeQuery()) {
		                if (results.next()) {
		                    return new Genre(results.getInt("id"),
		                                    results.getString("name"));
		                }
		            }
		        }
		    } catch (SQLException e) {
		        // Manage Exception
		        e.printStackTrace();
		    }
		    return null;
	}

	public void addGenre(String name) {
		try (Connection connection = dataSource.getConnection()) {
	        String sqlQuery = "INSERT into genre(name) "+"VALUES('Horror)";
	        try (PreparedStatement statement = connection.prepareStatement(
	                        sqlQuery)) {
	            statement.setString(1, name);
	            statement.executeUpdate();
	            int nbRows = statement.executeUpdate();
				System.out.println("Nombre de lignes :"+nbRows);
	        }
	    }catch (SQLException e) {
	        // Manage Exception
	        e.printStackTrace();
	    }
	}
}
